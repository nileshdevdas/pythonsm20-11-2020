
import pytest 
from selenium.webdriver import Chrome


def test_google_homepage():
    driver = Chrome()
    print("Google Home Page....")