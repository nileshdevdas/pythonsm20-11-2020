import pickle 

# users = {"nilesh", "rames", "suresh", "tim", "tom"}

# serfile = open("d:/pickle.ser" , 'wb')

# pickle.dump(users, serfile);

readfile = open("d:/pickle.ser", 'rb')
musers = pickle.load(readfile)


print(musers)
# picking is faster than storing in xml of json it uses native format 
# json or xml or anyother form 


