from selenium import webdriver 
from selenium.webdriver.common.keys import Keys
import time

#pip install selenium
def test_google_home():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://www.google.com")
    assert "Google"  == driver.title
    driver.find_element_by_name("q").send_keys("Vinsys")
    time.sleep(4) 
    driver.find_element_by_name("btnK").send_keys(Keys.ENTER)
    time.sleep(4)
    driver.close();
