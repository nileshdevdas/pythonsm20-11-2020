import pytest

@pytest.mark.test1
def test_add2():
    pass


@pytest.mark.test1
def test_add3():
    pass


@pytest.mark.test1
def test_add4():
    pass


@pytest.mark.test1
def test_add5():
    pass


@pytest.mark.test1
def test_add6():
    pass
