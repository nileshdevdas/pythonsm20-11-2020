#smtplib is inbuilt in python ...... 
import smtplib
from email.mime.multipart import MIMEMultipart

# tell smtplibrary where is your  host and port
try:
    smtpservice = smtplib.SMTP(host='mail.vinsys.com', port=587)
    smtpservice.starttls()
    smtpservice.login('iot@vinsys.com', '7@5z2n7L')
    print(smtpservice)
    msg = MIMEMultipart()
    msg['From'] = 'iot@vinsys.com'
    msg['To'] = 'nilesh.devdas@gmail.com'
    msg['Subject'] = "Dummy Subject For Testing"

    smtpservice.send_message(msg)
except Exception as e:
    print(e)
finally:
    print("Will do the cleanup later")
