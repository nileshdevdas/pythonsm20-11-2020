

def demo_function():
    a = 10 
    b = 20 
    c = a + b
    print("This is a demo function....")


demo_function()