


def a1():
    a = 10
    b = 20 
    c = a + b 
    a2()



def a2():
    b = 30 
    c = 40 
    d =  b + c 


a1()

