import sys 

# nilesh.devdas@outlook.com

sys.exit("Ooops I exitd ")