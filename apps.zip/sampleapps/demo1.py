a = 10 
b = 20 

print(a+b)

print(a)
print(b)

if a < b: 
    print(a)
else:
    print(b)


maxage = 20 

if maxage < 10:
    print("You are small")
else:
    print("you are okay")