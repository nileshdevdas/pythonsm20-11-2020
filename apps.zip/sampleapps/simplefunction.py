"""
Simple function construct
"""


def calculate_tax(principal, taxrate):
    print(principal)
    print(taxrate)
    return (principal/100)*taxrate


"""
functions can have params 
function can return values 
functions can have params with default value ---> to the right must after non def value (right)
function can accept variable args 
function can accept kw args 
function can have both kwargs as well as varags  
"""


def calculate_premium(principal, taxrate=100):
    print(principal)
    print(taxrate)
    return (principal/100)*taxrate


def calulate_numbers(*args):
    sum = 0
    for a in args:
        sum = sum + a
    print(sum)


def process_config(**kwargs):
    print(kwargs['username'])
    print(kwargs['password'])
    print(kwargs['host'])
    print(kwargs['port'])
    print(kwargs['dbname'])


def process_all(*args, **kwargs):
    print(args)
    print(kwargs)


process_all(1, 3, 4, 5, a=10, b=20, c=30)







