

a = lambda x : x + 1

print(a)

print(a(10932))












