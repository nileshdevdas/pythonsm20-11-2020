"""
sample app
"""

AIRPORTS = []


def read_file(**kwargs):
    """
    reading file
    """
    file = open(file=kwargs['file'])
    line = file.readline()
    parse_data(line)


def parse_data(line):
    """
    Document for Method parse_data
    """
    print(line)
