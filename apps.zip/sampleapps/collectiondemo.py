users = []
newusers_range = range(1, 100)
for x in newusers_range:
    users.append(x)
print(users)
users2 = {1, 2, 3, 4, 5}
users2.add(5)
users2.add(5)
users2.add(5)
users2.add(5)
users2.add(6)
print(users2)
depts = {'001': 'Admin', '002': 'Sales', '003': 'Inventory', '004': 'CSM'}
print(depts.keys())
print(depts.values())
print(depts['001'])
