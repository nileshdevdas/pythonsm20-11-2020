"""
Airports processing application
"""


def process():
    """
    Function Level Documentation 
    """
    print("process")
    file = read_file(file_name="c:/airportsdata/airports.csv",
                     mode="r", encoding="utf-8")
    line = file.readline()
    while line:
        parsed_data = parse_data(line)
        line = file.readline()


def read_file(**kwargs):
    """
    Function Level document
    """
    if kwargs is None:
        return
    else:
        file_name = kwargs['file_name']
        mode = kwargs['mode']
        encoding = kwargs['encoding']
        file = open(file_name, mode=mode, encoding=encoding)
        return file


def parse_data(line=None, splitter=","):
    """
    Parse Data
    """
    print("this")


process()
