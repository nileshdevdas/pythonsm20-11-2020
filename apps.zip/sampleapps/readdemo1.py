# open is built in function
# open accepts minum the filename and mode but however the other options can be passed
# here we are using named parameters to open the file
small_airports = []
large_aiports = []
medium_airports = []

file = open(file='C:\\aiportsdata\\airports.csv', mode='r', encoding='utf-8')
# reading the first line
line = file.readline()

# while there are more lines kindly keep readning the file
while line:
    line = file.readline()
