

try:
    1/0
except ZeroDivisionError as e:
    print(e)
except Exception as e1:
    print(e1)
finally:
    print("finally")


# can i raise a exception
