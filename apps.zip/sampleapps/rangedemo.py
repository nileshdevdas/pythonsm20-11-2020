"""
This is a doc comment block  this acts a block comment 
@Author nilesh 
@version 1.0 
"""
# comment 

r1 = range(0,100, 2)
# range create a range of array type (Tuple  from strt , end , step)
# for i =0 ; i < end ; i= i + 2 
for r in r1:
    print(r)




    