
# r  read mode
# w  write mode
# a  write in appended (At end of the file)
# r+  r+w

file = open(file='C:/aiportsdata/airports.csv', mode='r',  encoding='utf-8')

line = file.readline()
count = 0;
while line:
    count = count + 1
    line = file.readline()

print("Total lines ")
print(count)