
def a(param1): return param1 > 2230

# i could use thse a anonymouse functions or name function to be passed as parameters callable parameters


print(a(1993))


###
nums = (1, 3, 9, 5, 2, 13, 8, 45, 36)
sorted_nums = sorted(nums, key=lambda val: val < 11)
print(sorted_nums)
