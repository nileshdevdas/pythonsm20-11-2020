

def process(**kwargs):
    filename = kwargs['file']
    thefile = read_file(file=filename)
    print(thefile)
    # read line by line


def read_file(**kwargs):
    pass


def parse_data(line=None, splitter=","):
    pass


def print_details(*args):
    print(args)


process(file="filesame")
