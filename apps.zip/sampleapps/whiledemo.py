a = 1
b = [1, 2, 3, 4]

while a < 10:
    print(a)
    a = a + 1

for x in b:
    print(x)

if a < 20:
    print("less")
elif a > 20:
    print("more")
else:
    print("equal")

myrange = range(1, 10, 2)

for m in myrange:
    print(m)


def myfunction():
    a = 10 
    b= 20 
    print("inside a function ....................................")
    print(a)
    print(b)

myfunction()