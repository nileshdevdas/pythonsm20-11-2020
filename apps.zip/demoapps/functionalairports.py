
# function validate 

# function to read a file
def  read_file(file):
    file = open(file= file, mode='r', encoding='utf-8')
    return file

# function 2 to find a airport 
def  find_airport(data, type):
     newdata = data.replace('"', "")
     splitdata = newdata.split(",")
     print(splitdata[2])
     return splitdata;

file = read_file("c://airportsdata//airports.csv")
line = file.readline()
while line:
    find_airport(type='small_airport', data=line)
    line = file.readline()








