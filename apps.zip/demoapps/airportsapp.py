"""
sys is inbuilt module for use for system configuration / sys 
"""
import sys

for arg in sys.argv:
    print(arg)

file = open(file=sys.argv[1], mode='r', encoding='utf-8')
small_airports = []
large_airports = []
medium_airports = []
other_airports = []
line = file.readline()
while line:
    trimline = line.replace('"', '')
    splitdata = trimline.split(",")
    airport_type = splitdata[2]
    airport_name = splitdata[3]
    if airport_type == 'small_airport':
        small_airports.append(airport_name)
    elif airport_type == 'medium_airport':
        medium_airports.append(airport_name)
    elif airport_type == 'large_airport':
        large_airports.append(airport_name)
    else:
        other_airports.append(airport_name)
    line = file.readline()
# if file is opened see that you close it for non leak of handles ....
file.close()
print("Total Number Airports Small : ", end="")
print(len(small_airports))
print("Total Number Airports Medium ", end="")
print(len(medium_airports))
print("Total Number Airports Large ", end="")
print(len(large_airports))
print("Total Airports ", end="")
print(len(small_airports) + len(medium_airports) + len(large_airports))
