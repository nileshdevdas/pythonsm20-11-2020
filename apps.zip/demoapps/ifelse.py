
maxage = 10
yourage = 20

if yourage <= maxage:
    print(1)
    print(2)
    print(3)
    print(4)
else:
    print(1)
    print(2)
    print(3)
